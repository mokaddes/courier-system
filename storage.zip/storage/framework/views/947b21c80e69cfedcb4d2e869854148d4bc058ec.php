<footer class="main-footer">
    <strong> <?php echo e(('Copyright')); ?> <?php echo e(date('Y')); ?> <?php echo e('Dhereydelivery.com'); ?></strong>
    <?php echo e(__('All Rights Reserved.')); ?>

</footer>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>