<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            $setting = App\Models\Setting::first();
        ?>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="theme-color" content="#ffffff">
        <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('frontend/images/favicons/apple-icon-60x60.png')); ?>">
        <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('frontend/images/favicons/apple-icon-72x72.png')); ?>">
        <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('frontend/images/favicons/apple-icon-76x76.png')); ?>">
        <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('frontend/images/favicons/apple-icon-114x114.png')); ?>">
        <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('frontend/images/favicons/apple-icon-120x120.png')); ?>">
        <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('frontend/images/favicons/apple-icon-144x144.png')); ?>">
        <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('frontend/images/favicons/apple-icon-152x152.png')); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('frontend/images/favicons/apple-icon-180x180.png')); ?>">
        <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('frontend/images/favicons/android-icon-192x192.png')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('frontend/images/favicons/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('frontend/images/favicons/favicon-96x96.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('frontend/images/favicons/favicon-16x16.png')); ?>">
        <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($setting->site_name); ?></title>
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset($setting->favicon)); ?>" type="image/x-icon">
        
        <?php echo $__env->yieldPushContent('meta'); ?>
        
        <?php echo $__env->make('frontend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset('massage/toastr/toastr.css')); ?>">
        
        <?php echo $__env->yieldPushContent('css'); ?>
    </head>
    <body>
        
        <header class="header-section sticky-top">
            <?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>
        
        <?php echo $__env->yieldContent('content'); ?>
        
        <footer class="footer-section pb-4 pt-4">
            <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
        <!-- js -->
        <?php echo $__env->make('frontend.layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <script src="<?php echo e(asset('massage/toastr/toastr.js')); ?>"></script>
        <?php echo Toastr::message(); ?>

        <script>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error('<?php echo e($error); ?>','Error',{
                        closeButton:true,
                        progressBar:true,
                    });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </script>
        
        <?php echo $__env->yieldPushContent('js'); ?>
    </body>
</html>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>