<script src="<?php echo e(asset('backend/js/jquery.min.js')); ?>"></script>
<script src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('backend/adminlte/bootstrap4/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="https://adminlte.io/themes/v3/plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo e(asset('backend/adminlte/js/adminlte.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/layouts/script.blade.php ENDPATH**/ ?>