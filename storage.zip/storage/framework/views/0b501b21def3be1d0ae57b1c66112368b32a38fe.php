<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/frontend/layouts/foot.blade.php ENDPATH**/ ?>