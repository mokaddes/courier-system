

<?php $__env->startSection('pickup-request', 'active'); ?>
<?php $__env->startSection('title'); ?> Pickup Request <?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Pickup Request</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Pickup Request</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="row align-items-center">
                                    <div class="col-6">
                                        <h3 class="card-title">Manage Pickup Request</h3>
                                    </div>
                                    <div class="col-6">
                                        <div class="float-right">
                                            
                                            <a class="btn btn-primary" href="<?php echo e(route('admin.pickup-request.create')); ?>">Add
                                                New</a>
                                            

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap jsgrid-table" id="dataTables">
                                    <thead>
                                        <tr>
                                            <th width="5%">SL</th>
                                            <th width="10%">Pickup name</th>
                                            <th width="10%">Address</th>
                                            <th width="10%">Phone</th>
                                            <th width="10%">Date</th>
                                            <th width="10%">Dhereye Delivery Rate</th>
                                            <th width="10%">Status</th>
                                            <th width="10%">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(isset($pickup_requests) && count($pickup_requests) > 0): ?>
                                            <?php $__currentLoopData = $pickup_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($key + 1); ?></td>
                                                    <td><?php echo e($row->pickup_name); ?></td>
                                                    <td><?php echo e($row->pickup_address); ?></td>
                                                    <td><?php echo e($row->pickup_mobile); ?></td>
                                                    <td><?php echo e(date('d M Y', strtotime($row->created_at))); ?></td>
                                                    <td class="text-center"><?php echo e(getprice($row->amount)); ?></td>
                                                    <td>
                                                        <?php if($row->status == 1): ?>
                                                            <span class="badge badge-success">Active</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger">Inactive</span>
                                                        <?php endif; ?>

                                                    </td>
                                                    <td>
                                                        <?php if(Auth::user()->can('admin.pickup-request.edit')): ?>
                                                        <a class="btn btn-success edit btn-xs"
                                                            href="<?php echo e(route('admin.pickup-request.edit', $row->id)); ?>">Edit</a>
                                                          <?php endif; ?>
                                                        <?php if(Auth::user()->can('admin.pickup-request.view')): ?>   
                                                        <a class="btn btn-info view btn-xs"
                                                            href="<?php echo e(route('admin.pickup-request.view', $row->id)); ?>">View</a>
                                                        <?php endif; ?>    
                                                       

                                                        <?php if(Auth::user()->can('admin.pickup-request.edit')): ?>
                                                            <?php if($row->status == 1): ?>
                                                                <a class="btn btn-secondary active btn-xs"
                                                                    href="<?php echo e(route('admin.pickup-request.status.inactive', $row->id)); ?>">Inactive</a>
                                                            <?php else: ?>
                                                                <a class="btn btn-warning active btn-xs"
                                                                    href="<?php echo e(route('admin.pickup-request.status.active', $row->id)); ?>">Active</a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                        

                                                        <?php if(Auth::user()->can('admin.pickup-request.delete')): ?>
                                                        <a class="btn btn-danger btn-xs" id="deleteData"
                                                            href="<?php echo e(route('admin.pickup-request.delete', $row->id)); ?>">Delete</a>
                                                        <?php endif; ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/pickup-request/index.blade.php ENDPATH**/ ?>