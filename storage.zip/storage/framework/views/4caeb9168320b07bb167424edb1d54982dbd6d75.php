<?php
    $settings = DB::table('settings')->first();
?>
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a class="brand-link" href="<?php echo e(route('admin.dashboard')); ?>">
        <span class="brand-text font-weight-light">
            <?php echo e($settings->site_name); ?>

        </span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" data-accordion="false" role="menu">
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('dashboard'); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="nav-icon fa fa-dashboard"></i>
                        <?php echo e(__('Dashboard')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('merchant-user'); ?>" href="<?php echo e(route('admin.merchant.index')); ?>">
                        <i class="fa fa-user-plus"></i>
                        <?php echo e(__('Merchant')); ?>

                    </a>
                </li>

                
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('pickup-request'); ?>" href="<?php echo e(route('admin.pickup-request.index')); ?>">
                        <i class="nav-icon fa fa-fa fa-bars"></i>
                        <?php echo e(__('Pickup Request')); ?>

                    </a>
                </li>
                
                <li class="nav-item <?php echo $__env->yieldContent('price_menu'); ?> ">
                    <a class="nav-link " href="javascript:;">
                        <i class="fa-solid fa-dollar-sign"></i>
                        <p>
                            <?php echo e(__('Price')); ?>

                            <i class="fas fa-angle-left right"></i>

                        </p>
                    </a>
                    <ul class="nav nav-treeview <?php echo $__env->yieldContent('price_menu'); ?>">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('price_group'); ?>" href="<?php echo e(route('admin.price-group.index')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('Price Group')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('price'); ?>" href="<?php echo e(route('admin.price.index')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('Prices')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.weights.index')); ?>" class="nav-link <?php echo $__env->yieldContent('weight'); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('Weight')); ?></p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php if(Auth::user()->can('admin.contact.index')): ?>
                    <li class="nav-item">
                        <a class="nav-link  <?php echo $__env->yieldContent('contact'); ?>" href="<?php echo e(route('admin.contact.index')); ?>">
                            <i class="nav-icon fa fa-address-book"></i>
                            <?php echo e(__('Contact')); ?>

                        </a>
                    </li>
                <?php endif; ?>

                <?php if(Auth::user()->can('admin.faq.index')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $__env->yieldContent('faq'); ?>" href="<?php echo e(route('admin.faq.index')); ?>">
                            <i class="nav-icon fa fa-question"></i>
                            <?php echo e(__('Faq')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            
                

                <li class="nav-item <?php echo $__env->yieldContent('location_menu'); ?> ">
                    <a class="nav-link " href="javascript:;">
                        <i class="nav-icon fas fa-location"></i>
                        <p>
                            <?php echo e(__('Location')); ?>

                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview <?php echo $__env->yieldContent('location_menu'); ?>">
                        <?php if(Auth::user()->can('admin.country.index')): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $__env->yieldContent('country'); ?>" href="<?php echo e(route('admin.country.index')); ?>">
                                    <i class="nav-icon far fa-circle"></i>
                                    <p><?php echo e(__('Country')); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->can('admin.region.index')): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $__env->yieldContent('region'); ?>" href="<?php echo e(route('admin.region.index')); ?>">
                                    <i class="nav-icon far fa-circle"></i>
                                    <p><?php echo e(__('Region')); ?></p>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('cities'); ?>" href="<?php echo e(route('admin.cities.index')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('City')); ?></p>
                            </a>
                        </li>
                        
                    </ul>
                </li>

                <li class="nav-item <?php echo $__env->yieldContent('adnin_user_role'); ?> ">
                    <a class="nav-link " href="<?php echo e(route('admin.settings')); ?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p>
                            <?php echo e(__('Admin & Role')); ?>

                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('admin-user'); ?>" href="<?php echo e(route('admin.user.index')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <?php echo e(__('Admin')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('admin-roles'); ?>" href="<?php echo e(route('admin.roles.index')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <?php echo e(__('Roles')); ?>

                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('admin-permissions'); ?>" href="<?php echo e(route('admin.permissions.index')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <?php echo e(__('Role permissions')); ?>

                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item <?php echo $__env->yieldContent('settings_menu'); ?> ">
                    <a class="nav-link " href="<?php echo e(route('admin.settings')); ?>">
                        <i class="nav-icon fas fa-cog"></i>
                        <p>
                            <?php echo e(__('Settings')); ?>

                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>

                    <ul class="nav nav-treeview <?php echo $__env->yieldContent('settings_menu'); ?>">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.settings.general')); ?>" class="nav-link <?php echo $__env->yieldContent('general'); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('General Settings')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('language'); ?>" href="<?php echo e(route('admin.settings.language')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('Language')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('smpt'); ?>" href="<?php echo e(route('admin.settings.smtp.mail')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('SMTP')); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $__env->yieldContent('currency'); ?>"
                                href="<?php echo e(route('admin.settings.currency.index')); ?>">
                                <i class="nav-icon far fa-circle"></i>
                                <p><?php echo e(__('Currency')); ?></p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>