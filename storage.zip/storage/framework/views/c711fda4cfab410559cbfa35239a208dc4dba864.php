

<?php $__env->startSection('admin-user', 'active'); ?>
<?php $__env->startSection('title'); ?> Admin| role edit <?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(__('Admin role edit')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('Admin role edit')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="m-0"><?php echo e(__('Admin user role')); ?>

                                    <span class="float-right">
                                    <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-sm btn-primary"> <= back</a>
                                    </span>
                                </h5>
                            </div>
                            <div class="card-body">


                                <form method="POST" action="<?php echo e(route('admin.roles.update',$role->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="name" class="form-label">Role Name</label>
                                        <input value="<?php echo e($role->name); ?>"
                                            type="text"
                                            class="form-control"
                                            name="name"
                                            placeholder="Name" required>

                                        <?php if($errors->has('name')): ?>
                                            <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="mb-3">
                                       <div class="row">
                                           <div class="col-3">
                                            <div class="custom-control custom-checkbox">
                                            <input
                                                <?php echo e(App\Models\Admin::roleHasPermission($role, $permissions) ? 'checked' : ''); ?>

                                                class="custom-control-input" type="checkbox" id="permission_all" value="1">
                                            <label for="permission_all" class="custom-control-label"><?php echo e(__('All')); ?></label>
                                           </div>
                                           </div>
                                       </div>
                                    </div>

                                    <div class="mb-3">
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $permissionss = App\Models\Admin::getpermissionsByGroupName($group->name);
                                                $j = 1;
                                            ?>
                                            <div class="row">
                                                <div class="col-3">
                                                    <div class="custom-control custom-checkbox">
                                                        <input
                                                            <?php echo e(App\Models\Admin::roleHasPermission($role, $permissions) ? 'checked' : ''); ?>

                                                            class="custom-control-input" type="checkbox"
                                                            id="<?php echo e($i); ?>management"
                                                            onclick="CheckPermissionByGroup('role-<?php echo e($i); ?>-management-checkbox',this)"
                                                            value="2">
                                                        <label for="<?php echo e($i); ?>management"
                                                            class="custom-control-label text-capitalize"><?php echo e($group->name); ?></label>
                                                    </div>
                                                </div>
                                                <div class="col-9 role-<?php echo e($i); ?>-management-checkbox">
                                                    <?php $__currentLoopData = $permissionss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="custom-control custom-checkbox">
                                                            <input
                                                                onclick="checksinglepermission('role-<?php echo e($i); ?>-management-checkbox','<?php echo e($i); ?>management',<?php echo e(count($permissionss)); ?>)"
                                                                <?php echo e($role->hasPermissionTo($permission->name) ? 'checked' : ''); ?>

                                                                name="permissions[]" class="custom-control-input"
                                                                type="checkbox"
                                                                id="permission_checkbox_<?php echo e($permission->id); ?>"
                                                                value="<?php echo e($permission->name); ?>">
                                                            <label for="permission_checkbox_<?php echo e($permission->id); ?>"
                                                                class="custom-control-label"><?php echo e(__($permission->name)); ?></label>
                                                        </div>
                                                        <?php $j++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <hr>
                                            <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>


                                    <button type="submit" class="btn btn-primary">Save</button>

                                </form>


                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $('#permission_all').click(function() {
            if ($(this).is(':checked')) {
                // check all the checkbox
                $('input[type=checkbox]').prop('checked', true);
            } else {
                // uncheck all the checkbox
                $('input[type=checkbox]').prop('checked', false);
            }
        });

        // check permission by group
        function CheckPermissionByGroup(classname, checkthis) {
            const groupIdName = $("#" + checkthis.id);
            const classCheckBox = $('.' + classname + ' input');
            if (groupIdName.is(':checked')) {
                // check all the checkbox
                classCheckBox.prop('checked', true);
            } else {
                // uncheck all the checkbox
                classCheckBox.prop('checked', false);
            }
        }
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>