

<?php $__env->startSection('adnin_user_role', 'menu-open'); ?>

<?php $__env->startSection('admin-permissions', 'active'); ?>

<?php $__env->startSection('title'); ?> Admin| permissions <?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(__('Admin permissions')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('Admin permissions')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="m-0"><?php echo e(__('Admin permissions list')); ?>

                                    <span class="float-right">
                                    <a href="<?php echo e(route('admin.permissions.create')); ?>" class="btn btn-sm btn-primary">+ Add new</a>
                                    </span>
                                </h5>
                            </div>
                            <div class="card-body">
                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th scope="col" width="15%">Name</th>
                                        <th scope="col">Guard</th>
                                        <th scope="col" colspan="3" width="1%"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($permission->name); ?></td>
                                                <td><?php echo e($permission->guard_name); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('admin.permissions.edit', $permission->id)); ?>" class="btn btn-info btn-sm">Edit</a>
                                                </td>
                                                <td>
                                                    <?php echo Form::open(['method' => 'POST','route' => ['admin.permissions.destroy', $permission->id],'style'=>'display:inline']); ?>

                                                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-sm']); ?>

                                                    <?php echo Form::close(); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/permissions/index.blade.php ENDPATH**/ ?>