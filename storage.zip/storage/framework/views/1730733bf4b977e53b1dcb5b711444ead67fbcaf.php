
<?php $__env->startPush('style'); ?>
<style>
    .img {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
    width: 80px;
    height: 70px;
  }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('adnin_user_role', 'menu-open'); ?>


<?php $__env->startSection('admin-user', 'active'); ?>

<?php $__env->startSection('title'); ?> Admins <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $userr = Auth::user();
    ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(__('Admins')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('Admins')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="m-0"><?php echo e(__('Admin List')); ?>

                                    <div class="float-right">
                                        <a href="<?php echo e(route('admin.user.create')); ?>"
                                            class="btn btn-primary">Add New</a>

                                    </div>
                                </h5>
                            </div>
                            <div class="card-body table-responsive p-0">
                                <table id="dataTables" class="table table-hover text-nowrap jsgrid-table">
                                    <thead>
                                        <tr>
                                            <th width="5%">Sl</th>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Email')); ?></th>
                                            <th><?php echo e(__('Image')); ?></th>
                                            <th width="10%"><?php echo e(__('action')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(isset($users) && $users->count() > 0): ?>
                                       <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td>
                                                <?php if($item->image): ?>
                                                <img src="<?php echo e(asset($item->image)); ?>" class="img" alt="Image">
                                                <?php else: ?>
                                                <img src="<?php echo e(asset('uploads/default-user.png')); ?>" class="img" alt="Image">
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.user.edit',$item->id)); ?>" id="" class="btn btn-success btn-sm">Edit</a>
                                                <a href="<?php echo e(route('admin.user.show',$item->id)); ?>" id="" class="btn btn-secondary btn-sm">View</a>
                                                
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>    
                                    </tbody>
                                </table>
                            </div>
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/users/index.blade.php ENDPATH**/ ?>