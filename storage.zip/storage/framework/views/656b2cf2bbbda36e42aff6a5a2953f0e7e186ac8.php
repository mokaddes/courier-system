<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            $setting = App\Models\Setting::first();
        ?>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e($setting->site_name); ?></title>
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset($setting->favicon)); ?>" type="image/x-icon">
        
        <?php echo $__env->make('admin.layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset('massage/toastr/toastr.css')); ?>">
        <link href="https://adminlte.io/themes/v3/plugins/summernote/summernote-bs4.min.css" rel="stylesheet">
        <link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        
        <?php echo $__env->yieldPushContent('style'); ?>
    </head>
    <body class="hold-transition sidebar-mini">
        <div class="wrapper">
            
            <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->yieldContent('content'); ?>
            
            <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <?php echo $__env->make('admin.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
        <script src="<?php echo e(asset('massage/toastr/toastr.js')); ?>"></script>

        <?php echo Toastr::message(); ?>


        <script>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error('<?php echo e($error); ?>', 'Error', {
                        closeButton: true,
                        progressBar: true,
                    });
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </script>

        <script>
            $('#dataTables').DataTable();

            $('.summernote').summernote({
                height: 200,
            });

            $('.select2').select2();
        </script>
        
        <script>
            $(document).on("click", "#deleteData", function(e) {
                e.preventDefault();
                var link = $(this).attr("href");
                Swal.fire({
                    title: 'Are you want to delete?',
                    text: "Once Delete, This will be Permanently Delete!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#8bc34a',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((willDelete) => {
                    if (willDelete.isConfirmed) {
                        window.location.href = link;
                    }
                })
            })
        </script>
        
        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/layouts/master.blade.php ENDPATH**/ ?>