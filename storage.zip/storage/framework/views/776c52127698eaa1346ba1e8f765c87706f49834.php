

<?php $__env->startPush('style'); ?>
<style>
    .img {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
    width: 80px;
    height: 70px;
  }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('adnin_user_role', 'menu-open'); ?>

<?php $__env->startSection('admin-user', 'active'); ?>

<?php $__env->startSection('title'); ?> Admin|Update <?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(__('Admin update')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('Admin update')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="m-0"><?php echo e(__('Admin Update')); ?>

                                    <span class="float-right">
                                        <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-sm btn-primary">
                                            Back</a>
                                    </span>
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('admin.user.update',$admin->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-lg-12 mb-3">
                                            
                                            <label for="email" class="form-label">Image </label>
                                            <input  type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="image" >
                                            <?php if($errors->has('image')): ?>
                                                <span class="text-danger text-left"><?php echo e($errors->first('image')); ?></span>
                                            <?php endif; ?>
                                            <?php if($admin->image): ?>
                                            <img src="<?php echo e(asset($admin->image)); ?>" class="img mt-2" alt="Image">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset('uploads/default-user.png')); ?>" class="img mt-2" alt="Image">
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="col-lg-4 mb-3">
                                            <label for="name" class="form-label">Name *</label>
                                            <input value="<?php echo e($admin->name); ?>" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="name" placeholder="Name" autocomplete="off" required>
    
                                            <?php if($errors->has('name')): ?>
                                                <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label for="email" class="form-label">Email *</label>
                                            <input value="<?php echo e($admin->email); ?>" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="email" placeholder="Email address" autocomplete="off" required>
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <label for="password" class="form-label">Password *</label>
                                            <input value="<?php echo e(old('password')); ?>" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="password" placeholder="Enter Password" autocomplete="off" >
                                            <?php if($errors->has('password')): ?>
                                                <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>