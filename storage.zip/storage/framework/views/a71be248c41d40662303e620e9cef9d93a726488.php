<?php
    $setting = App\Models\Setting::first();
    // dd($setting);
?>
<div class="container">
    <div class="row gy-4">
        <div class="col-xl-4">
            <div class="footer-widget mb-4">
                <h3><?php echo e(__('Contact Information')); ?></h3>
            </div>
            <div class="contact_info">
                <div class="d-flex align-items-center mb-3">
                    <div class="icon">
                        <i class="la la-phone-volume"></i>
                    </div>
                    <div class="address">
                        <strong><?php echo e(__('Phone:')); ?></strong>
                        <a href="tel:<?php echo e(__($setting->phone_no)); ?>"><?php echo e(__($setting->phone_no)); ?></a>
                    </div>
                </div>
                <div class="d-flex align-items-center mb-3">
                    <div class="icon">
                        <i class="la la-map-marker"></i>
                    </div>
                    <div class="address">
                        <strong><?php echo e(__('Head Office:')); ?></strong>
                        <?php echo e(__($setting->office_address)); ?>

                    </div>
                </div>
                <div class="d-flex align-items-center mb-3">
                    <div class="icon">
                        <i class="la la-envelope"></i>
                    </div>
                    <div class="address">
                        <strong><?php echo e(__('Email:')); ?></strong>
                        <a href="mailto:<?php echo e(__($setting->email)); ?>"><?php echo e(__($setting->email)); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2 ps-xl-5">
            <div class="footer-widget mb-4">
                <h3><?php echo e(__('About')); ?></h3>
            </div>
            <div class="links">
                <ul>
                    <li><a href="<?php echo e(route('about')); ?>"><?php echo e(__('About Us')); ?></a></li>
                    <li><a href="<?php echo e(route('contact')); ?>"><?php echo e(__('Contact Us')); ?></a></li>
                    <li><a href="<?php echo e(route('pricing')); ?>"><?php echo e(__('Pricing')); ?></a></li>
                    <li><a href="<?php echo e(route('ecommerce')); ?>"><?php echo e(__('Ecommerce')); ?></a></li>
                </ul>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="footer-widget mb-4">
                <h3><?php echo e(__('Help & Suppor')); ?>t</h3>
            </div>
            <div class="links">
                <ul>
                    <li><a href="<?php echo e(route('privacy.policy')); ?>"><?php echo e(__('Privacy Policy')); ?></a></li>
                    <li><a href="<?php echo e(route('terms.onditions')); ?>"><?php echo e(__('Terms & Conditions')); ?></a></li>
                    <li><a href="<?php echo e(route('tracking')); ?>"><?php echo e(__('Tracking')); ?></a></li>
                    <li><a href="<?php echo e(route('pickup.request')); ?>"><?php echo e(__('Pick Up Request')); ?></a></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 col-md-4 col-xl-4">
            <div class="footer-widget mb-4">
                <h3><?php echo e(__('Get In Touch')); ?></h3>
            </div>
            <div class="social_media">
                <ul>
                    <?php if($setting->facebook_url): ?>
                        <li>
                            <a href="<?php echo e($setting->facebook_url); ?>">
                                <i class="la la-facebook"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($setting->twitter_url): ?>
                        <li>
                            <a href="<?php echo e($setting->twitter_url); ?>">
                                <i class="la la-twitter"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($setting->linkedin_url): ?>
                        <li>
                            <a href="<?php echo e($setting->linkedin_url); ?>">
                                <i class="la la-linkedin"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($setting->instagram_url): ?>
                        <li>
                            <a href="<?php echo e($setting->instagram_url); ?>">
                                <i class="la la-instagram"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($setting->youtube_url): ?>
                        <li>
                            <a href="<?php echo e($setting->youtube_url); ?>">
                                <i class="la la-youtube"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($setting->telegram_url): ?>
                        <li>
                            <a href="https://t.me/+<?php echo e($setting->telegram_url); ?>">
                                <i class="la la-telegram"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if($setting->whatsapp_number): ?>
                        <li>
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e($setting->whatsapp_number); ?>">
                                <i class="la la-whatsapp"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="copyright text-center pt-4">
        <p><?php echo e(__($setting->copyright_text)); ?></p>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>