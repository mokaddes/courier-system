<?php
    $setting = App\Models\Setting::first();
?>
<div class="container">
    <!-- desktop menu -->
    <nav class="navbar navbar-expand-lg p-0">
        <div class="container-fluid">
            <a class="navbar-brand p-0" href="<?php echo e(route('home')); ?>">
                <img src="<?php if($setting->site_logo): ?> <?php echo e(asset($setting->site_logo)); ?> <?php else: ?> <?php echo e(asset('frontend/images/logo.png')); ?> <?php endif; ?>"
                    alt="logo">
            </a>
            <div class="d-flex align-items-center">
                <a class="login_btn d-block d-lg-none me-3" href="<?php echo e(route('login')); ?>">
                    <img src="<?php echo e(asset('frontend/images/icons/login-user.svg')); ?>" alt="">
                    <?php echo e(__('Login')); ?>

                </a>
                <button class="navbar-toggler" data-bs-toggle="offcanvas" data-bs-target="#mobileNavExample"
                    type="button" type="button" aria-controls="mobileNavExample">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('tracking')); ?>"><?php echo e(__('Track')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pricing')); ?>"><?php echo e(__('Pricing')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('ecommerce')); ?>"><?php echo e(__('Ecommerce')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pickup.request')); ?>"><?php echo e(__('Pick Up Request')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>"><?php echo e(__('Contact Us')); ?></a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <?php if(Auth::Check()): ?>
                        <a class="login_btn" href="<?php echo e(route('user.dashboard')); ?>">
                            <?php if(Auth::user()->image): ?>
                                <img class="rounded-circle"
                                    src="<?php echo e(asset('frontend/images/profile/' . Auth::user()->image)); ?>"
                                    alt="Profile Image" width="50px">
                            <?php else: ?>
                                <img class="rounded-circle" src="<?php echo e(asset('frontend/default-user.png')); ?>"
                                    alt="Profile Image" width="50px">
                            <?php endif; ?>
                            Profile
                        </a>
                    <?php else: ?>
                        <a class="login_btn" href="<?php echo e(route('login')); ?>">
                            <img src="<?php echo e(asset('frontend/images/icons/login-user.svg')); ?>" alt="">
                            Login
                        </a>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <!-- mobile menu -->
    <div class="mobile_nav d-block d-lg-none">
        <div class="offcanvas offcanvas-start" id="mobileNavExample" aria-labelledby="mobileNavExampleLabel"
            tabindex="-1">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title" id="mobileNavExampleLabel">
                    <a href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="logo">
                    </a>
                </h5>
                <button class="btn-close" data-bs-dismiss="offcanvas" type="button" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('tracking')); ?>"><?php echo e(__('Track')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pricing')); ?>"><?php echo e(__('Pricing')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('ecommerce')); ?>"><?php echo e(__('Ecommerce')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('pickup.request')); ?>"><?php echo e(__('Pick Up Request')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>"><?php echo e(__('Contact Us')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>