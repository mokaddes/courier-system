

<?php $__env->startSection('price_menu', 'menu-open'); ?>

<?php $__env->startSection('price_group', 'active'); ?>

<?php $__env->startSection('title'); ?> <?php echo e($data['title'] ?? ''); ?> <?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="<?php echo e(asset('backend/css/bootstrap4-toggle.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e($data['title'] ?? ''); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active"><?php echo e($data['title'] ?? ''); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="row align-items-center">
                                    <div class="col-6">
                                        <h3 class="card-title">Manage <?php echo e($data['title'] ?? ''); ?> </h3>
                                    </div>
                                    <div class="col-6">
                                        <div class="float-right">

                                            <a class="btn btn-primary" href="<?php echo e(route('admin.price-group.create')); ?>">Add
                                                New</a>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body table-responsive p-0">
                                <table class="table table-hover text-nowrap jsgrid-table" id="dataTables">
                                    <thead>
                                        <tr>

                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Status</th>
                                            <th class="text-center">Action</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data['pricingGroups']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricingGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($pricingGroup->name); ?></td>
                                                <td>
                                                    <?php if(Auth::user()->can('admin.price-group.edit')): ?>
                                                    <input id="status" data-toggle="toggle" data-on="Active"
                                                        data-off="Inactive" data-id="<?php echo e($pricingGroup->id); ?>"
                                                        data-onstyle="success" data-offstyle="danger" type="checkbox"
                                                        onchange="status(this)"
                                                        <?php if($pricingGroup->status): ?> checked <?php endif; ?>>
                                                    <?php endif; ?>    
                                                </td>
                                                <td class="d-flex justify-content-around">
                                                    <?php if(Auth::user()->can('admin.price-group.edit')): ?>
                                                    <a class="btn btn-info btn-sm"
                                                        href="<?php echo e(route('admin.price-group.edit', ['price_group' => $pricingGroup->id])); ?>"><i
                                                            class="fas fa-edit"></i></a>
                                                    <?php endif; ?>
                                                    <?php if(Auth::user()->can('admin.price-group.delete')): ?>        
                                                    <a class="btn btn-danger btn-sm"
                                                        href="<?php echo e(route('admin.price-group.delete', ['price_group' => $pricingGroup->id])); ?>"><i
                                                            class="fas fa-trash-alt"></i></a>
                                                     <?php endif; ?>       
                                                    <a class="btn btn-info btn-sm"
                                                        href="<?php echo e(route('admin.price.index', ['price_group' => $pricingGroup->id])); ?>"><i
                                                            class="fa fa-usd"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('backend/js/bootstrap4-toggle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/axios.min.js')); ?>"></script>
    <script>
        function status(event) {


            const {
                id
            } = event.dataset;
            let state = event.checked;


            axios.post("<?php echo e(route('admin.price-group.status')); ?>", {
                id,
                state
            }).then((response) => {
                const {
                    data
                } = response;
                if (data) {
                    toastr.success('Price group is activate', {
                        "closeButton": true,
                    });



                } else {
                    toastr.error('Price group is inactivate', {
                        "closeButton": true,
                    });


                }
            }).catch((error) => {
                console.log(error);
            })




        };
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/price-group/index.blade.php ENDPATH**/ ?>