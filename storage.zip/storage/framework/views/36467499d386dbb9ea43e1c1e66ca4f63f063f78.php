<!-- google fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;500;600;700;800;900&display=swap"
    rel="stylesheet">
<!-- css -->
<link href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css"
    rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/main.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet">
<?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/frontend/layouts/head.blade.php ENDPATH**/ ?>