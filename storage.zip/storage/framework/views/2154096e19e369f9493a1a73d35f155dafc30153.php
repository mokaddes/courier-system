
<?php $__env->startPush('style'); ?>
<style>
    .img {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
    width: 100px;
    height: 120px;
  }
</style>
<?php $__env->stopPush(); ?>



<?php $__env->startSection('merchant-user', 'active'); ?>

<?php $__env->startSection('title'); ?> Merchant | Details <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $userr = Auth::user();
    ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0"><?php echo e(__('Merchant')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('Merchant')); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="m-0"><?php echo e(__('Merchant Details')); ?>

                                    <div class="float-right">
                                        <a href="<?php echo e(route('admin.user.index')); ?>"
                                            class="btn btn-primary">Back</a>

                                    </div>
                                </h5>
                            </div>
                            <div class="card-body table-responsive p-0">
                                <table class="table table-striped">
                                    <tr>
                                    <td style="width: 20%">Merchant Image</td>
                                    <td style="width: 80%"><img src="<?php echo e(asset($admin->image)); ?>" class="img" alt="admin user image"></td>
                                </tr>
                                    <tr>
                                        <td style="width: 20%"> Name</td>
                                        <td style="width: 80%"><?php echo e($admin->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td style="width:20%">Email</td>
                                        <td style="width:80%"><?php echo e($admin->email); ?></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 20%">Date</td>
                                        <td style="width: 80%"><?php echo e(date('d M Y', strtotime($admin->created_at))); ?></td>
                                    </tr>
                                  
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/admin/merchant/view.blade.php ENDPATH**/ ?>