

<?php $__env->startSection('title'); ?>
    <?php echo e(__('Pricing')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('meta'); ?>
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('frontend/images/favicons/apple-icon-60x60.png')); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('frontend/images/favicons/apple-icon-72x72.png')); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('frontend/images/favicons/apple-icon-76x76.png')); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('frontend/images/favicons/apple-icon-114x114.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('frontend/images/favicons/apple-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('frontend/images/favicons/apple-icon-144x144.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('frontend/images/favicons/apple-icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('frontend/images/favicons/apple-icon-180x180.png')); ?>">
    <link rel="icon" type="image/png" sizes="192x192"
        href="<?php echo e(asset('frontend/images/favicons/android-icon-192x192.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('frontend/images/favicons/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('frontend/images/favicons/favicon-96x96.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('frontend/images/favicons/favicon-16x16.png')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ======================= start  ========================= -->
    <div class="breadcrumb_sec mt-5 mb-5">
        <div class="container">
            <div class="text-center">
                <h4><?php echo e(__('Pricing')); ?></h4>
                <p><?php echo e(__('DhereyeDelivery Rate Chart [Only Somalia City Mogadishu area]')); ?></p>
            </div>
        </div>
    </div>
    <!-- ======================= end  ============================ -->

    <!-- ======================= pricing start  ========================== -->
    <div class="pricing-sec mb-5">
        <div class="container">
            <!-- Regular Delivery -->
            <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="pricing-table">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tbody>

                            <tr>
                                <th colspan="5"><?php echo e($price->name); ?></th>
                            </tr>
                            <tr>
                                <th width="110">Item</th>
                                <th>Products Weight</th>
                                <th width="120">Inter City Price</th>
                                <th width="120">Insite City Price</th>
                            </tr>
                            <?php $__currentLoopData = $price->pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pricing->item_name); ?></td>
                                <td><?php echo e($pricing->hasWeight->name?? ""); ?></td>
                                <td><?php echo e(getPrice($pricing->inside_main_city_price)?? ""); ?></td>
                                <td><?php echo e(getPrice($pricing->inter_city_price)?? ""); ?></td>
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\test\dhereyedelivery\resources\views/frontend/pages/pricing.blade.php ENDPATH**/ ?>